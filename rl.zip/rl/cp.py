form cpuwatch import matricsCpu


def new():
    while True:
	metricsCpu()

